import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';


@Component({
  selector: 'my-app',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  name = 'Angular';
  
  private gridApi;
  private gridColumnApi;
  private columnDefs;
  private sortingOrder;


 
  constructor(private http: HttpClient){

    this.columnDefs=[
      {
        headerName: "athlete",
        field: "athlete",
        width: 150,
        sortingOrder:["asc","desc"]
      },
        {
        headerName: "age",
        field: "age",
        width: 150,
        sortingOrder:["asc","desc"]
      },
        {
        headerName: "country",
        field: "country",
        width: 150,
        sortingOrder:["asc","desc"]
      },
        {
        headerName: "year",
        field: "year",
        width: 150,
        sortingOrder:["asc","desc"]
      },
        {
        headerName: "date",
        field: "date",
        width: 150,
        sortingOrder:["asc","desc"]
      },
        {
        headerName: "sport",
        field: "sport",
        width: 150,
        sortingOrder:["asc","desc"]
      },
        {
        headerName: "gold",
        field: "gold",
        width: 150,
        sortingOrder:["asc","desc"]
      },
      {
        headerName:"silver",
        field:"silver",
        width: 150,
        sortingOrder:["asc","desc"]
      },
      {
        headerName:"bronze",
        field:"bronze",
        width: 150,
        sortingOrder:["asc","desc"]
        },
      {
        headerName:"total",
        field:"total",
        width: 150,
        sortingOrder:["asc","desc"]
  }
    ]
  }
    

  
  
  onGridReady(params){
    this.gridApi = params.api;
    this.gridColumnApi = params.colummnApi;

this.http.get("https://raw.githubusercontent.com/ag-grid/ag-grid-docs/master/src/olympicWinnersSmall.json").subscribe(data=>{
  params.api.setRowData(data);
})
    //let dataValue=[{"firstName":"harsha","age": 22},{"firstName":"Madan","age": 24}]
    


  }

}
